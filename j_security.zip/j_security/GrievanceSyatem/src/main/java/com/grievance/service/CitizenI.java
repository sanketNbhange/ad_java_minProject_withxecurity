package com.grievance.service;

import java.util.List;

import com.grievance.model.Complaint;

public interface CitizenI {
	public static String addressId = "A"+Math.round(Math.random() * 9999);
	public static String complaintId = "C"+Math.round(Math.random() * 9999);

	
	public String registerCitizen(String name, String email, String password, String mobileNo,String houseNo, String landMark, String pincode) throws Exception;
	public List<Complaint> getAllCitizenComplaints(String userId) throws Exception;
	public int updateCitizenRemark(String compaintId, String message) throws Exception;
	public int updateReminder(String complaintId) throws Exception;
	
	public String addComplaint(String complaintMsg,  byte[] docs, String deptId) throws Exception;

}
