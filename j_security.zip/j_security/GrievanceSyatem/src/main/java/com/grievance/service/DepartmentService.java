package com.grievance.service;

import java.util.List;

import com.grievance.dao.AdminDao;
import com.grievance.dao.AdminDaoImpl;
import com.grievance.dao.DepartDaoimpl;
import com.grievance.dao.DepartmentDao;
import com.grievance.dao.UserDaoI;
import com.grievance.dao.UserDaoImpl;
import com.grievance.dto.ComplaintDto;
import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;
import com.grievance.model.User;
public class DepartmentService implements DepartmentI{
	DepartmentDao deptDao = new DepartDaoimpl();
	UserDaoI userDao = new UserDaoImpl();
	DepartmentDao departmentDao = new DepartDaoimpl();
	AdminDao adminDao = new AdminDaoImpl();



	@Override
	public int transferComplaint(String complaintId, String deptId) throws Exception {
		
		return deptDao.transferComplaint(complaintId, deptId);
	}

	@Override
	public int updateStatus(String complaintId, String status) throws Exception {
		
		return departmentDao.updateStatus(complaintId, status);
	}
	@Override
	public List<ComplaintDto> getAllComplaintsBtDeptId(String deptid) throws Exception {
		return new DepartDaoimpl().getAllComplaintByDeptId(deptid);
	}

	@Override
	public int updateHeadRemark(String complaintId, String message) throws Exception {
		
		return departmentDao.updateDeptRemark(complaintId, message);
	}
}
