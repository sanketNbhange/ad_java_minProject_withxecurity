package com.grievance.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.grievance.service.CitizenI;
import com.grievance.service.CitizenService;


public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CitizenI citizenService=new CitizenService();
    
	public UserController() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getPathInfo();
		if (path.equals("/adduser")) {
			try {
				String name = request.getParameter("name");
				String email = request.getParameter("email");
				String password = request.getParameter("password");
				String mobileNumber = request.getParameter("mobileNo");
				String houseNo = request.getParameter("houseNo");
				String landMark = request.getParameter("landmark");
				String pincode = request.getParameter("pincode");
				citizenService.registerCitizen(name, email, password, mobileNumber, houseNo, landMark, pincode);
				System.out.println("before");
				response.sendRedirect("/GrievanceSyatem/index.jsp");
				System.out.println("after");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
