package com.grievance.dao;

import java.util.List;

import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Complaint;
import com.grievance.model.Department;
import com.grievance.model.User;

public interface AdminDao {
   public List<Department> getAllDepartment() throws Exception;
   public List<DepartmentHeadDto> getAllDepartmentInfo() throws Exception;
   public int deleteDepartment(String deptId) throws Exception;
   public int updateDepartment(Department department) throws Exception;
   public User getUserByName(String name) throws Exception;//change the name.........
   public int addEmployee(User user) throws Exception;
   public List<User> getAllFreeDeptHead() throws Exception;
   public int addDepartment(Department department) throws Exception;
	public Department getDepartmentById(String deptId) throws Exception;

}
