function formValidation(){
	
	var uname=document.registration.name;
	var uemail=document.registration.email;
	var password=document.registration.password;
	var confirm_password=document.registration.confirm_password;
	var mob=document.registration.mobile;
	pincode=document.registration.pincode;
	
	 letters = /^[A-Z a-z]+$/;
	if(!uname.value.match(letters))
	{
		alert('Username must have alphabet characters only');
		uname.focus();
		return false;
	}
	
	
	 mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(!uemail.value.match(mailformat))
	{
		alert("You have entered an invalid email address!");
		uemail.focus();
		return false;
	}
	
	if(password.value.length == '' || password.value.length >12 || password.value.length <8){
		alert("Password should be between 8-12");
		password.focus();
		return false;
	} 
	
	
	if(!password.value.match(confirm_password.value)){
		
		confirm_password.focus();
		return false;
	}
	
	regex=/[0-9 -()+]+$/;
	if(mob.value.length !=10 || (!mob.value.match(regex))){
		alert("Please Enter 10 digit mobile number");
		mob.focus();
		return false;
	}
	
	
	regex=/^\d{6}$/;
	if(!pincode.value.match(regex)){
		alert("Please enter a valid pincode");
		pincode.focus();
		return false;
	}
	

}

$(document).ready(function(){
	
	$('#password, #confirm_password').on('keyup', function () 
	{
  		if($('#password').val() == $('#confirm_password').val()) 
  		{
    		$('#message').html('Matching').css('color', 'green');
  		}else 
    		$('#message').html('Not Matching').css('color', 'red');
	});
})

