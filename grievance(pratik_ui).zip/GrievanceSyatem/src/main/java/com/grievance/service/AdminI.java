package com.grievance.service;

import java.util.List;

import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;
import com.grievance.model.User;

public interface AdminI {
	public static String getDeptId() { 
		return "D"+ Math.round(Math.random() * 9999);
	};

	public List<Department> getAllDepartment() throws Exception;
	public List<DepartmentHeadDto> getAllDepartmentInfo() throws Exception;
	
	public String registerDepartment(String deptName, String userName) throws Exception;
	public int deleteDepartment(String deptid) throws Exception;
	public int updateDepartment(String deptName, String userName, String deptId) throws Exception;
	public List<Department> getALLDepartment() throws Exception;
	public Department getDepartmentById(String deptId) throws Exception;
	
	public String registerEmployee(String name, String email, String password,
			String mobileNo, String role)
			throws Exception;
	public List<User> getAllFreeDeptHead() throws Exception;
}
