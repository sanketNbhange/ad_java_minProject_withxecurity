package com.grievance.service;

import java.time.LocalDate;
import java.util.List;

import com.grievance.dao.CitizenDaoI;
import com.grievance.dao.CitizenDaoImpl;
import com.grievance.model.Address;
import com.grievance.model.Complaint;
import com.grievance.model.ComplaintStatus;
import com.grievance.model.Role;
import com.grievance.model.User;

public class CitizenService implements CitizenI {

	CitizenDaoI citizenDao = new CitizenDaoImpl();
	public static LocalDate getCurrentDate() {
		LocalDate dt = LocalDate.now(); 
		return dt;
	}
	public String registerCitizen(String name, String email, String password, String mobileNo, String houseNo, String landMark, String pincode) throws Exception {
		User user = new User(UserI.getUserId(), name, email, password, mobileNo, Role.CITIZEN.toString());
		String userId = citizenDao.addCitizen(user);
		Address address = new Address(CitizenI.addressId, houseNo, landMark, pincode, userId);
		int addressStatus = citizenDao.addAddress(address);
		if(addressStatus == 1)
		{ 
			return landMark;
		}
		else {
			throw new Exception("could not create user please try again");
		}
	}
	@Override
	public List<Complaint> getAllCitizenComplaints(String userId) throws Exception {
		return citizenDao.getAllCitizenComplaint(userId);
	}
	@Override
	public int updateCitizenRemark(String compaintId, String message) throws Exception {
		
		return citizenDao.updateCitizenRemark(compaintId, message);
	}
	@Override
	public int updateReminder(String complaintId) throws Exception {
		
		return citizenDao.updateReminder(complaintId);
	}
	@Override
	public String addComplaint(String complaintMsg, byte[] docs, String deptId) throws Exception {
		Complaint complaint  = new Complaint();
		complaint.setComplaintId( "C"+ Math.round(Math.random()*999));
		complaint.setComplaintMsg(complaintMsg);
		complaint.setDocs(docs);
		complaint.setComplaintDate(getCurrentDate());
		complaint.setDeptId(deptId);
		complaint.setComplaintStatus(ComplaintStatus.PENDING.toString());
		
		int status = citizenDao.registerComplaint(complaint);
		if(status == 1)
		{
			return complaintMsg;
		}
		else
		{
			throw new Exception("Cannot register compalint please try again");
		}
	}
}
