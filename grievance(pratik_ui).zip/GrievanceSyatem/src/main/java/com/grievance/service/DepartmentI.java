package com.grievance.service;

import java.util.List;

import com.grievance.dto.ComplaintDto;

public interface DepartmentI {
	public int transferComplaint(String complaintId, String deptId) throws Exception;
	public int updateStatus(String complaintId, String status) throws Exception;
	public List<ComplaintDto> getAllComplaintsBtDeptId(String deptid) throws Exception;
	public int updateHeadRemark(String complaintId, String message) throws Exception;
}
