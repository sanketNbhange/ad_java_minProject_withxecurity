package com.grievance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.grievance.dbutil.DbUtil;
import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;
import com.grievance.model.Role;
import com.grievance.model.User;

public class AdminDaoImpl implements AdminDao {

	public int addDepartment(Department department) throws Exception {
		String sql = "INSERT INTO department values(?,?,?)";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, department.getDeptId());
		ps.setString(2, department.getDeptName());
		ps.setString(3, department.getUserId());
		return ps.executeUpdate();
	
	}

	@Override
	public int deleteDepartment(String deptId) throws Exception {
		String sql = "delete from department where deptid = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);		
		ps.setString(1, deptId);			
		return ps.executeUpdate();
	}
	
	@Override
	public int updateDepartment(Department department) throws Exception {
		String query = "update department set deptname= ?, userid=? where deptid = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(query);		
		ps.setString(1, department.getDeptName());
		ps.setString(2, department.getUserId());
		ps.setString(3, department.getDeptId());
		return ps.executeUpdate();
	}

	public List<Department> getAllDepartment() throws Exception {
		String sql = "SELECT * FROM department";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<Department> departments = new ArrayList<Department>();
		while (rs.next()) {
			departments.add(new Department(rs.getString(1),rs.getString(2),rs.getString(3)));
		}
		return departments;
	}

	@Override
	public List<DepartmentHeadDto> getAllDepartmentInfo() throws Exception {
		String sql = "SELECT department.deptname , IFNULL( user.name , \"NA\") as head, IFNULL( user.email , \"NA\") as email ,department.deptid\r\n"
				+ "from department \r\n"
				+ "left outer join user on user.userid = department.userid";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<DepartmentHeadDto> departmentInfo = new ArrayList<DepartmentHeadDto>();
		while (rs.next()) {
			departmentInfo.add(new DepartmentHeadDto(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
		}
		return departmentInfo;
	}
	
	public User getUserByName(String name) throws Exception {
		String query = "SELECT * FROM user where  name= ?";
		Connection con = DbUtil.getConnection();
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, name);
		ResultSet rs = ps.executeQuery();
		User  user = null;
		if(rs.next()) {
			user = new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
		}
		System.out.println(user.toString());
		return user;
	}
	public int addEmployee(User user) throws Exception {
		String query  = "INSERT INTO user values(?,?,?,?,?,?)";
		Connection con = DbUtil.getConnection();
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, user.getUserId());
		ps.setString(2, user.getName());
		ps.setString(3, user.getEmail());
		ps.setString(4, user.getMobileNo());
		ps.setString(5, user.getPassword());
		ps.setString(6, user.getRole());
		return ps.executeUpdate();
	}
	
	@Override
	public List<User> getAllFreeDeptHead() throws Exception {
		String role = Role.DEPARTMENTHEAD.toString();
		String query = "select * FROM user where role = ? and user.userid not in (select userid from department where userid is not null);";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setString(1, role);
		ResultSet rs = ps.executeQuery();
		List<User> userList = new ArrayList<User>();
		while(rs.next()) {
			userList.add(new User(rs.getString(1), rs.getString(2), 
					rs.getString(3), rs.getString(4),
					rs.getString(5), rs.getString(6)));
		}
		System.out.println(userList);
		return userList;
	}
	@Override
	public Department getDepartmentById(String deptId) throws Exception {
		String query="select * from department where deptid = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setString(1, deptId);
		ResultSet rs = ps.executeQuery();
		Department department=null;
		if(rs.next()) {
		department = new Department(rs.getString(1), rs.getString(2), rs.getString(3));
		}
		return department;
	}


}
