package com.grievance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.grievance.dbutil.DbUtil;
import com.grievance.dto.ComplaintDto;
import com.grievance.model.Address;
import com.grievance.model.Complaint;
import com.grievance.model.ComplaintStatus;
import com.grievance.model.User;

public class CitizenDaoImpl implements CitizenDaoI{

	java.util.Date date=new java.util.Date();
	
	java.sql.Date sqlDate=new java.sql.Date(date.getTime());
	java.sql.Timestamp sqlTime=new java.sql.Timestamp(date.getTime());
	//addNewUser In database
	public String addCitizen(User user) throws Exception {
		String query= "insert into user values(?,?,?,?,?,?)";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(query);

		ps.setString(1, user.getUserId());
		ps.setString(2, user.getName());
		ps.setString(3, user.getEmail());
		ps.setString(4, user.getMobileNo());
		ps.setString(5, user.getPassword());
		ps.setString(6, user.getRole());
		ps.executeUpdate();
		return user.getUserId();
	}

	@Override
	public List<Complaint> getAllCitizenComplaint(String userId) throws Exception {
		String sql = "SELECT * FROM complaint where userid = ?" ;
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, userId);
		ResultSet rs = ps.executeQuery();

		List<Complaint> complaints = new ArrayList<Complaint>();
		while (rs.next()) {
			complaints.add(new Complaint(rs.getString(1), rs.getString(2), rs.getBytes(3), rs.getInt(4),
					rs.getDate(5).toLocalDate(), rs.getDate(6).toLocalDate(), rs.getString(7), rs.getString(8), 
					rs.getString(9),  rs.getString(10), rs.getString(11), rs.getString(12),rs.getDate(13).toLocalDate()));
		}
		return complaints;
	}

	@Override
	public int updateCitizenRemark(String complaintId, String message) throws Exception {
		String sql = "UPDATE complaint set userremark = ? where complaintid = ? ";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, message);
		ps.setString(2, complaintId);
		return ps.executeUpdate();
	}

	@Override
	public int updateReminder(String complaintId) throws Exception {
		
		int updateCount=getCount(complaintId)+1;
		String status=ComplaintStatus.PENDING.toString();
		String sql = "UPDATE complaint set updatecount = ?, complaintstatus = ? where complaintid = ? ";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setInt(1, updateCount);
		ps.setString(2, status);
		ps.setString(3, complaintId);
		return ps.executeUpdate();
	}

	@Override
	public int getCount(String complaintId) throws Exception {
		String query="select updatecount from complaint where complaintid = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setString(1, complaintId);
		ResultSet rs=ps.executeQuery();
	//	int count=0;
		if(rs.next()) {
			return rs.getInt(1);
		}
		return 0;
	}
	@Override
	public int registerComplaint(Complaint complaint) throws Exception {
		String query = "INSERT INTO complaint values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		System.out.println(complaint.toString());
		Connection con = DbUtil.getConnection();
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, complaint.getComplaintId());
		ps.setString(2, complaint.getComplaintMsg());
		ps.setBytes(3, complaint.getDocs());
		ps.setString(4, "0");
		ps.setDate(5,  sqlDate);
		ps.setDate(6,  sqlDate);
		ps.setString(7, complaint.getComplaintStatus());
		ps.setString(8, complaint.getUserId());
		ps.setString(9, complaint.getDeptId());
		ps.setString(10, complaint.getAddressId());
		ps.setString(11, "0");
		ps.setString(12, "0");
		ps.setTimestamp(13, sqlTime);
		return ps.executeUpdate();
	}


	public int addAddress(Address address) throws Exception {
		String query = "INSERT INTO address values(?,?,?,?,?)";
		Connection con = DbUtil.getConnection();
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, address.getAddressId());
		ps.setString(2, address.getHouseNo());
		ps.setString(3, address.getLandMark());
		ps.setString(4, address.getPincode());
		ps.setString(5, address.getUserId());
		return ps.executeUpdate();
	}

	//get user by email and password
//	public User getCitizen(String email, String password) throws Exception {
//		String query = "select * from user where email=? and password=?";
//		Connection connection = DbUtil.getConnection();
//		PreparedStatement ps = connection.prepareStatement(query);
//		ps.setString(1, email);
//		ps.setString(2, password);
//		ResultSet rs = ps.executeQuery();
//		User  user = null;
//		if(rs.next()) {
//			user = new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
//		}
//		return user;
//	}

}
