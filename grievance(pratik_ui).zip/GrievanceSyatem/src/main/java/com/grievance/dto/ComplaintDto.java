package com.grievance.dto;

import java.time.LocalDate;
import java.util.Arrays;

public class ComplaintDto {
	private String complaintid;
	private String name;
	private String email;
	 private String complaintmsg;
	 private String userRemark;
	 private String headRemark;
	 private byte[] screenshot;
	 private LocalDate complaintDate;
	 private  int updateCount;
	 private String complaintStatus;
	public ComplaintDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ComplaintDto(String complaintid, String name, String email, String complaintmsg, String userRemark,
			String headRemark, byte[] screenshot, LocalDate complaintDate, int updateCount, String complaintStatus) {
		super();
		this.complaintid = complaintid;
		this.name = name;
		this.email = email;
		this.complaintmsg = complaintmsg;
		this.userRemark = userRemark;
		this.headRemark = headRemark;
		this.screenshot = screenshot;
		this.complaintDate = complaintDate;
		this.updateCount = updateCount;
		this.complaintStatus = complaintStatus;
	}

	public String getComplaintid() {
		return complaintid;
	}

	public void setComplaintid(String complaintid) {
		this.complaintid = complaintid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getComplaintmsg() {
		return complaintmsg;
	}

	public void setComplaintmsg(String complaintmsg) {
		this.complaintmsg = complaintmsg;
	}

	public String getUserRemark() {
		return userRemark;
	}

	public void setUserRemark(String userRemark) {
		this.userRemark = userRemark;
	}

	public String getHeadRemark() {
		return headRemark;
	}

	public void setHeadRemark(String headRemark) {
		this.headRemark = headRemark;
	}

	public byte[] getScreenshot() {
		return screenshot;
	}

	public void setScreenshot(byte[] screenshot) {
		this.screenshot = screenshot;
	}

	public LocalDate getComplaintDate() {
		return complaintDate;
	}

	public void setComplaintDate(LocalDate complaintDate) {
		this.complaintDate = complaintDate;
	}

	public int getupdateCount() {
		return updateCount;
	}

	public void setupdateCount(int updateCount) {
		this.updateCount = updateCount;
	}

	public String getComplaintStatus() {
		return complaintStatus;
	}

	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}

	@Override
	public String toString() {
		return "ComplaintDto [complaintid=" + complaintid + ", name=" + name + ", email=" + email + ", complaintmsg="
				+ complaintmsg + ", userRemark=" + userRemark + ", headRemark=" + headRemark + ", screenshot="
				+ Arrays.toString(screenshot) + ", complaintDate=" + complaintDate + ", updateCount=" + updateCount
				+ ", complaintStatus=" + complaintStatus + "]";
	}
	
}
