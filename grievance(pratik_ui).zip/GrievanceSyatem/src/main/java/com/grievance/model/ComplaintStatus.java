package com.grievance.model;

public enum ComplaintStatus {
 PENDING,RESOLVED,INPROCESS,CLOSED
}
