package com.grievance.controller;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.grievance.dto.ComplaintDto;
import com.grievance.model.Complaint;
import com.grievance.model.Department;
import com.grievance.service.AdminI;
import com.grievance.service.AdminService;
import com.grievance.service.DepartmentI;
import com.grievance.service.DepartmentService;
public class DepartmentHeadController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	DepartmentI departmentService = new DepartmentService(); 
	AdminI adminService=new AdminService();
	public DepartmentHeadController() {
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getPathInfo();
		if (path.equals("/getAllComplaints")) {
			try {
				List<ComplaintDto> complaints=new ArrayList<ComplaintDto>();
				complaints = departmentService.getAllComplaintsBtDeptId("D101");
				request.setAttribute("complaints", complaints);
				request.getRequestDispatcher("/head/view-complaints-head.jsp").forward(request, response);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		else if(path.equals("/editcomplaint")) {
			try {
				String complaintId=request.getParameter("complaintid");
				request.setAttribute("complaintid",complaintId);
				request.getRequestDispatcher("/head/update-complaint.jsp").forward(request, response);				
			} catch (Exception e) {
				e.printStackTrace();
			}



		}
		else if(path.equals("/updateremark")) {
			System.out.println("Hello ji");
			try {
				String complaintId=request.getParameter("complaintid");
				String message = request.getParameter("message");
				departmentService.updateHeadRemark(complaintId, message);
				response.sendRedirect("/GrievanceSyatem/DepartmentHeadController/getAllComplaints");				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		else if(path.equals("/transfercomplaintform")) {
			try {
				String complaintId=request.getParameter("complaintid");
				request.setAttribute("complaintid",complaintId);
				List<Department> listDept = adminService.getALLDepartment();
				request.setAttribute("department",listDept);
				request.getRequestDispatcher("/head/transfer-complaint.jsp").forward(request, response);

			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
		else if(path.equals("/transfercomplaint")) {
			try {
				String complaintId=request.getParameter("complaintid");
				String deptId = request.getParameter("deptid");
				departmentService.transferComplaint(complaintId, deptId);
				response.sendRedirect("/GrievanceSyatem/DepartmentHeadController/getAllComplaints");
			} catch (Exception e) {

				e.printStackTrace();
			}	
		}
		else if(path.equals("/updatestatus")) {
			try {
				String complaintId=request.getParameter("complaintid");
				String status = request.getParameter("status");
				departmentService.updateStatus(complaintId, status);
				response.sendRedirect("/GrievanceSyatem/DepartmentHeadController/getAllComplaints");
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);

	}

}
